    <div class="container my-5">

        <!-- Banner -->
        <div class="banner">
           <img src="#" alt="">
        </div>

        <!-- Seção de Categorias -->
        <div class="cat row text-center">
            <div class="col-3">
                <div class="card card-categoria">
                    <a href=""><img src="assets/img/frutas.jpg" class="card-categoria card-img-top" alt="..."></a> 
                </div>
            </div>
            <div class="col-3">
                <div class="card card-categoria">
                    <a href=""><img src="assets/img/legumes.jpg" class="card-categoria card-img-top" alt="..."></a>
                </div>
            </div>
            <div class="col-3">
                <div class="card card-categoria">
                    <a href=""><img src="assets/img/alemento.jpg" class="card-categoria card-img-top" alt="..."></a>
                </div>
            </div>
            <div class="col-3">
                <div class="card card-categoria">
                    <a href=""><img src="assets/img/carnes.jpg" class="card-categoria card-img-top" alt="..."></a>
                </div>
            </div>
        </div>

        <!-- Seção de  Produtos -->
        <h2 class="text-center my-4">Produtos</h2>
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div><img class="img-produto" src="assets/img/logo.png" alt=""></div>
                    <div class="card-body">
                        <h5 class="my-2">Nome do Produto do BD</h5>
                        <p>Descrição do Produto do BD</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div><img class="img-produto" src="assets/img/logo.png" alt=""></div>
                    <div class="card-body">
                        <h5 class="my-2">Nome do Produto do BD</h5>
                        <p>Descrição do Produto do BD</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div><img class="img-produto" src="assets/img/logo.png" alt=""></div>
                    <div class="card-body">
                        <h5 class="my-2">Nome do Produto do BD</h5>
                        <p>Descrição do Produto do BD</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div><img class="img-produto" src="assets/img/logo.png" alt=""></div>
                    <div class="card-body">
                        <h5 class="my-2">Nome do Produto do BD</h5>
                        <p>Descrição do Produto do BD</p>
                    </div>
                </div>
            </div>
        </div>
    </div>